import os
import re
from flask import Flask,render_template, url_for, request, redirect
import hashlib
import RSA
import datetime
import requests
import json

app = Flask(__name__)

#From the keys folder grab all the keys and put them into a dictionary after hashing them
files = os.listdir("keys/")
RSAkeys = {
    'kyelor' :
    {   'full_name': "Kyelor Curtis",
        'private' : None,
        'public' : None
    },
    'kym' :
    {   'full_name': "Kymberlee Sables",
        'private' : None,
        'public' : None
    },
    'damon' :
    {   'full_name': "Damon Green",
        'private' : None,
        'public' : None
    }
}

#For each file in the keys/ directory: hash them and put them in the correct spot in the keys dictionary
for file in files:
    #Read in the files, open them, and encode them
    encodedContent = open('keys/'+file).read().encode()
    hashVal = hashlib.sha256(encodedContent).hexdigest()
    #Decide who the owner of the key is and place them in the cooresponding dictionary value
    fileInfo = file.split('_')
    RSAkeys[fileInfo[0]][fileInfo[1][:-4]] = hashVal


#INDEX PAGE
#Connect the URLs to the cooresponding HTML files
@app.route('/', methods = ['GET','POST'])
def index():

    #Collect data from website form
    if request.method == 'POST':
        user = request.form.get("user")
        if user in RSAkeys.keys():
            #Package data for the transaction page
            currUser = RSAkeys[user]["full_name"]
            pubKey = RSAkeys[user]["public"]
            return redirect(f"/transaction/{user}/{pubKey}/{currUser}")
        else:
            return render_template('login.html', error = 'Invalid Login')
    return render_template('login.html', error = None)


#TRANSACTION PAGE
#This will grab the two people involved in a transaction
@app.route('/transaction/<user>/<pubKey>/<currUser>', methods = ['GET','POST'])
def transaction(user, pubKey, currUser):

    #Collect data from website form
    if request.method == 'POST':
        amount = request.form.get("amountNum")
        recipient = request.form.get("uname")
        if recipient in RSAkeys.keys():
            #Package data for the API call
            recipientPubKey = RSAkeys[recipient]["public"]
            data = str(datetime.datetime.now())+pubKey+recipientPubKey+amount

            #Create an unique signature for the transaction
            sendPubSig = RSA.encrypt(data)
            transactionDetails = {"Amount" : float(amount),"Hash" : str(RSA.forwardSHA(data))[:5],"PublicKeyRecipient" : str(recipientPubKey),"PublicKeySender" : str(pubKey),"Signature" : str(sendPubSig)}
            url = 'https://ohyy0are04.execute-api.us-east-1.amazonaws.com/dev/post'
            headers={}
            completedTransDetails = ('$'+str(format(transactionDetails["Amount"],'.2f'))+' has been sent to '+RSAkeys[recipient]["full_name"]+'.')
            transactionDetails = json.dumps(transactionDetails)
            res = requests.post(url, data=transactionDetails, headers=headers)
            print(res.text)
            return render_template('transaction.html', userName = user, completedTrans=completedTransDetails, error = None, currFullName = RSAkeys[user]["full_name"], publicKey = pubKey)
        else:
            print(RSAkeys[user]["full_name"])
            return render_template('transaction.html', userName = user, completedTrans= None,error = 'Recipient User Not Found', currFullName = RSAkeys[user]["full_name"], publicKey = pubKey)
    return render_template('transaction.html', userName = user,completedTrans= None, currFullName = currUser, publicKey = pubKey, error = None)




if __name__ == '__main__':
    app.run(debug= True)