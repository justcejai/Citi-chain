'use strict';

const crypto = require('crypto');
const AWS = require('aws-sdk'); // eslint-disable-line import/no-extraneous-dependencies
const dynamoDb = new AWS.DynamoDB.DocumentClient();

async function getPrevHash() {
  try {
    var params = {
      TableName: "CitiChain",
      ScanIndexForward: false
    };
    var result = await dynamoDb.scan(params).promise();
    result.Items.sort((a,b) => a.BlockNum - b.BlockNum);
    if (result.Count === 0) {
      return 0;
    }
    return result.Items[result.Count - 1].Hash;

  } catch (error) {
    console.error(error);
  }
}

async function createBlockNum() {
  try {
    var params = {
      TableName: "CitiChain",
      ScanIndexForward: false
    };
    var result = await dynamoDb.scan(params).promise();
    result.Items.sort((a,b) => a.BlockNum - b.BlockNum);
    if (result.Count === 0) {
      return 0;
    }
    return (result.Items[result.Count - 1].BlockNum) + 1;

  } catch (error) {
    console.error(error);
  }
}

async function findNonce(message, hash, nonce) {
  //Find the proper nonce that will make the hash start with four 0s
  while (hash.substring(0, 4) !== "0000") {
    nonce++;
    hash = crypto.createHash("sha256").update(message + nonce.toString(), "utf-8").digest();
  }
  return nonce;
}

const addTransaction = async function (event, context, callback) {
  const timestamp = new Date().getTime().toString();
  const data = JSON.parse(event.body);
  let blockNum = await createBlockNum();
  let nonce = 0;
  const message = timestamp + data.PublicKeySender + data.PublicKeyRecipient
    + data.Amount.toString();
  let hash = crypto.createHash("sha256").update(message + nonce.toString(), "utf-8").digest("hex").toString();
  let prevHash = await getPrevHash();

  const params = {
    TableName: "CitiChain",
    Item: {
      BlockNum: blockNum,
      PublicKeySender: data.PublicKeySender,
      PublicKeyRecipient: data.PublicKeyRecipient,
      Amount: data.Amount,
      Nonce: nonce,
      Hash: hash,
      PrevHash: prevHash,
      Signature: data.Signature
    }
  };

  // write the transaction to the database
  await dynamoDb.put(params).promise().then(function (data) {
    const response = {
      statusCode: 200,
      body: JSON.stringify(params.Item),
    };
    callback(null, response);
  })
};

module.exports = { addTransaction };