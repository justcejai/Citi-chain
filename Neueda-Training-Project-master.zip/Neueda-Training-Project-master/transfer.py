import hashlib

def SHA256(message):
    encoded = message
    hashVal = hashlib.sha256(encoded)
    return hashVal.hexdigest()