import requests
data = '{"Amount" : 1234.6,"Hash" : "12jslh2","PublicKeyRecipient" : "2342","PublicKeySender" : "2121","Signature" : "12311"}'
url = 'https://ohyy0are04.execute-api.us-east-1.amazonaws.com/dev/post'
headers={}
res = requests.post(url, data=data, headers=headers)

print(data, res.text)